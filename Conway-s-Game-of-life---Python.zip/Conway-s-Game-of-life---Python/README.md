# Conway-s-Game-of-life---Python
## subscribe to my youtube channel: [Auctux](https://www.youtube.com/channel/UCjPk9YDheKst1FlAf_KSpyA)
---
### Requirements
> **Pygame** : pip install pygame

> **Numpy**  : pip install numpy
---
### COMMANDS
        "Esc"             : to close the window
        "Space"           : to Pause the simulation
        "Mouse Left Click": to draw on the grid
---
![git](https://user-images.githubusercontent.com/48150537/80609593-e6f6ab00-8a55-11ea-9b86-de7ef878a548.png)
---

![conway](https://user-images.githubusercontent.com/48150537/80609620-f118a980-8a55-11ea-9366-98f75728403e.png)

enjoy ✌️
